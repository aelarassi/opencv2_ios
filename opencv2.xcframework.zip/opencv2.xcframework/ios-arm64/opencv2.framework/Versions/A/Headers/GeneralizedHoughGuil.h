//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/imgproc.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>
#import "GeneralizedHough.h"





NS_ASSUME_NONNULL_BEGIN

// C++: class GeneralizedHoughGuil
/**
 * finds arbitrary template in the grayscale image using Generalized Hough Transform
 *
 * Detects position, translation and rotation CITE: Guil1999 .
 *
 * Member of `Imgproc`
 */
CV_EXPORTS @interface GeneralizedHoughGuil : GeneralizedHough


#ifdef __cplusplus
@property(readonly)_cv::Ptr<_cv::GeneralizedHoughGuil> nativePtrGeneralizedHoughGuil;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(_cv::Ptr<_cv::GeneralizedHoughGuil>)nativePtr;
+ (instancetype)fromNative:(_cv::Ptr<_cv::GeneralizedHoughGuil>)nativePtr;
#endif


#pragma mark - Methods


//
//  void _cv::GeneralizedHoughGuil::setXi(double xi)
//
- (void)setXi:(double)xi NS_SWIFT_NAME(setXi(xi:));


//
//  double _cv::GeneralizedHoughGuil::getXi()
//
- (double)getXi NS_SWIFT_NAME(getXi());


//
//  void _cv::GeneralizedHoughGuil::setLevels(int levels)
//
- (void)setLevels:(int)levels NS_SWIFT_NAME(setLevels(levels:));


//
//  int _cv::GeneralizedHoughGuil::getLevels()
//
- (int)getLevels NS_SWIFT_NAME(getLevels());


//
//  void _cv::GeneralizedHoughGuil::setAngleEpsilon(double angleEpsilon)
//
- (void)setAngleEpsilon:(double)angleEpsilon NS_SWIFT_NAME(setAngleEpsilon(angleEpsilon:));


//
//  double _cv::GeneralizedHoughGuil::getAngleEpsilon()
//
- (double)getAngleEpsilon NS_SWIFT_NAME(getAngleEpsilon());


//
//  void _cv::GeneralizedHoughGuil::setMinAngle(double minAngle)
//
- (void)setMinAngle:(double)minAngle NS_SWIFT_NAME(setMinAngle(minAngle:));


//
//  double _cv::GeneralizedHoughGuil::getMinAngle()
//
- (double)getMinAngle NS_SWIFT_NAME(getMinAngle());


//
//  void _cv::GeneralizedHoughGuil::setMaxAngle(double maxAngle)
//
- (void)setMaxAngle:(double)maxAngle NS_SWIFT_NAME(setMaxAngle(maxAngle:));


//
//  double _cv::GeneralizedHoughGuil::getMaxAngle()
//
- (double)getMaxAngle NS_SWIFT_NAME(getMaxAngle());


//
//  void _cv::GeneralizedHoughGuil::setAngleStep(double angleStep)
//
- (void)setAngleStep:(double)angleStep NS_SWIFT_NAME(setAngleStep(angleStep:));


//
//  double _cv::GeneralizedHoughGuil::getAngleStep()
//
- (double)getAngleStep NS_SWIFT_NAME(getAngleStep());


//
//  void _cv::GeneralizedHoughGuil::setAngleThresh(int angleThresh)
//
- (void)setAngleThresh:(int)angleThresh NS_SWIFT_NAME(setAngleThresh(angleThresh:));


//
//  int _cv::GeneralizedHoughGuil::getAngleThresh()
//
- (int)getAngleThresh NS_SWIFT_NAME(getAngleThresh());


//
//  void _cv::GeneralizedHoughGuil::setMinScale(double minScale)
//
- (void)setMinScale:(double)minScale NS_SWIFT_NAME(setMinScale(minScale:));


//
//  double _cv::GeneralizedHoughGuil::getMinScale()
//
- (double)getMinScale NS_SWIFT_NAME(getMinScale());


//
//  void _cv::GeneralizedHoughGuil::setMaxScale(double maxScale)
//
- (void)setMaxScale:(double)maxScale NS_SWIFT_NAME(setMaxScale(maxScale:));


//
//  double _cv::GeneralizedHoughGuil::getMaxScale()
//
- (double)getMaxScale NS_SWIFT_NAME(getMaxScale());


//
//  void _cv::GeneralizedHoughGuil::setScaleStep(double scaleStep)
//
- (void)setScaleStep:(double)scaleStep NS_SWIFT_NAME(setScaleStep(scaleStep:));


//
//  double _cv::GeneralizedHoughGuil::getScaleStep()
//
- (double)getScaleStep NS_SWIFT_NAME(getScaleStep());


//
//  void _cv::GeneralizedHoughGuil::setScaleThresh(int scaleThresh)
//
- (void)setScaleThresh:(int)scaleThresh NS_SWIFT_NAME(setScaleThresh(scaleThresh:));


//
//  int _cv::GeneralizedHoughGuil::getScaleThresh()
//
- (int)getScaleThresh NS_SWIFT_NAME(getScaleThresh());


//
//  void _cv::GeneralizedHoughGuil::setPosThresh(int posThresh)
//
- (void)setPosThresh:(int)posThresh NS_SWIFT_NAME(setPosThresh(posThresh:));


//
//  int _cv::GeneralizedHoughGuil::getPosThresh()
//
- (int)getPosThresh NS_SWIFT_NAME(getPosThresh());



@end

NS_ASSUME_NONNULL_END


