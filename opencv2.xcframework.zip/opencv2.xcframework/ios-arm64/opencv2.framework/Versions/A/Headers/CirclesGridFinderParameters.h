//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/calib3d.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


@class Size2f;


// C++: enum GridType (_cv.CirclesGridFinderParameters.GridType)
typedef NS_ENUM(int, GridType) {
    SYMMETRIC_GRID = 0,
    ASYMMETRIC_GRID = 1
};



NS_ASSUME_NONNULL_BEGIN

// C++: class CirclesGridFinderParameters
/**
 * The CirclesGridFinderParameters module
 *
 * Member of `Calib3d`
 */
CV_EXPORTS @interface CirclesGridFinderParameters : NSObject


#ifdef __cplusplus
@property(readonly)_cv::Ptr<_cv::CirclesGridFinderParameters> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(_cv::Ptr<_cv::CirclesGridFinderParameters>)nativePtr;
+ (instancetype)fromNative:(_cv::Ptr<_cv::CirclesGridFinderParameters>)nativePtr;
#endif


#pragma mark - Methods


//
//   _cv::CirclesGridFinderParameters::CirclesGridFinderParameters()
//
- (instancetype)init;


    //
    // C++: Size2f _cv::CirclesGridFinderParameters::densityNeighborhoodSize
    //

@property Size2f* densityNeighborhoodSize;

    //
    // C++: float _cv::CirclesGridFinderParameters::minDensity
    //

@property float minDensity;

    //
    // C++: int _cv::CirclesGridFinderParameters::kmeansAttempts
    //

@property int kmeansAttempts;

    //
    // C++: int _cv::CirclesGridFinderParameters::minDistanceToAddKeypoint
    //

@property int minDistanceToAddKeypoint;

    //
    // C++: int _cv::CirclesGridFinderParameters::keypointScale
    //

@property int keypointScale;

    //
    // C++: float _cv::CirclesGridFinderParameters::minGraphConfidence
    //

@property float minGraphConfidence;

    //
    // C++: float _cv::CirclesGridFinderParameters::vertexGain
    //

@property float vertexGain;

    //
    // C++: float _cv::CirclesGridFinderParameters::vertexPenalty
    //

@property float vertexPenalty;

    //
    // C++: float _cv::CirclesGridFinderParameters::existingVertexGain
    //

@property float existingVertexGain;

    //
    // C++: float _cv::CirclesGridFinderParameters::edgeGain
    //

@property float edgeGain;

    //
    // C++: float _cv::CirclesGridFinderParameters::edgePenalty
    //

@property float edgePenalty;

    //
    // C++: float _cv::CirclesGridFinderParameters::convexHullFactor
    //

@property float convexHullFactor;

    //
    // C++: float _cv::CirclesGridFinderParameters::minRNGEdgeSwitchDist
    //

@property float minRNGEdgeSwitchDist;

    //
    // C++: float _cv::CirclesGridFinderParameters::squareSize
    //

@property float squareSize;

    //
    // C++: float _cv::CirclesGridFinderParameters::maxRectifiedDistance
    //

@property float maxRectifiedDistance;


@end

NS_ASSUME_NONNULL_END


