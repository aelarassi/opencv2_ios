//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/video.hpp"
#import "opencv2/video/tracking.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>






NS_ASSUME_NONNULL_BEGIN

// C++: class Params
/**
 * The Params module
 *
 * Member of `Video`
 */
CV_EXPORTS @interface TrackerDaSiamRPNParams : NSObject


#ifdef __cplusplus
@property(readonly)_cv::Ptr<_cv::TrackerDaSiamRPN::Params> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(_cv::Ptr<_cv::TrackerDaSiamRPN::Params>)nativePtr;
+ (instancetype)fromNative:(_cv::Ptr<_cv::TrackerDaSiamRPN::Params>)nativePtr;
#endif


#pragma mark - Methods


//
//   _cv::TrackerDaSiamRPN::Params::Params()
//
- (instancetype)init;


    //
    // C++: string _cv::TrackerDaSiamRPN::Params::model
    //

@property NSString* model;

    //
    // C++: string _cv::TrackerDaSiamRPN::Params::kernel_cls1
    //

@property NSString* kernel_cls1;

    //
    // C++: string _cv::TrackerDaSiamRPN::Params::kernel_r1
    //

@property NSString* kernel_r1;

    //
    // C++: int _cv::TrackerDaSiamRPN::Params::backend
    //

@property int backend;

    //
    // C++: int _cv::TrackerDaSiamRPN::Params::target
    //

@property int target;


@end

NS_ASSUME_NONNULL_END


